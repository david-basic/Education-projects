import React from "react";
import PageContent from "../components/PageContent";
import { useRouteError } from "react-router-dom";
import MainNavigation from "../components/MainNavigation";

const ErrorPage = () => {
	const error = useRouteError();

	let title = "An error occured!";
	let message = "Something went wrong!";

	if (error.status === 500) {
		// message = JSON.parse(error.data).message;
		message = error.data.message; // we can do this cause we are throwing json format Response in the page where we look for a error
	}

	if (error.status === 404) {
		title = "404 Not found!";
		message = "Could not find resource or page!";
	}

	return (
		<>
			<MainNavigation />
			<PageContent title={title}>
				<p>{message}</p>
			</PageContent>
		</>
	);
};

export default ErrorPage;
