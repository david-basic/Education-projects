import { Await, defer, json, useLoaderData } from "react-router-dom";
import EventsList from "../components/EventsList";
import { Suspense } from "react";

function EventsPage() {
	const { events } = useLoaderData(); // fetched events

	return (
		<Suspense fallback={<p style={{ textAlign: "center" }}>Loading...</p>}>
			<Await resolve={events}>
				{(loadedEvents) => <EventsList events={loadedEvents} />}{" "}
			</Await>
		</Suspense>
	);
}

export default EventsPage;

const loadEvents = async () => {
	const response = await fetch("http://localhost:8080/events");

	if (!response.ok) {
		// handling incorrect response

		// throw new Response(
		// 	JSON.stringify({ message: "Could not fetch events!" }),
		// 	{ status: 500 }
		// );

		throw json({ message: "Could not fetch events!" }, { status: 500 }); // json format Response object as alternative so that we dont have to parse in the error page
	} else {
		// const responseData = await response.json();
		// // return responseData.events; // this data is made available to the EventsPage component in the App by using loader: property (any data returned is made available)
		// const res = new Response("any data", {status: 201});
		// return res;
		// you can not use react hooks in the loader function which you pass to the loader property!
		// return response; // we can do this because the promise that fetch returns is a browser builtin Response object

		const responseData = await response.json();
		return responseData.events;
	}
};

export const loader = () => {
	return defer({
		events: loadEvents(),
	});
};
