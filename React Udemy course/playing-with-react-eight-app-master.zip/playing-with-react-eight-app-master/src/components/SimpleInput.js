import React from "react";
import useInput from "../hooks/use-input-state";

const SimpleInput = (props) => {
	const {
		value: enteredName,
		isValid: enteredNameIsValid,
		hasError: nameInputHasError,
		inputChangeHandler: nameChangedHandler,
		inputBlurHandler: nameBlurHandler,
		resetInput: resetNameInput,
	} = useInput((value) => value.trim() !== "");

	const {
		value: enteredEmail,
		isValid: enteredEmailIsValid,
		hasError: emailInputHasError,
		inputChangeHandler: emailChangedHandler,
		inputBlurHandler: emailBlurHandler,
		resetInput: resetEmailInput,
	} = useInput((value) => value.trim() !== "" && value.includes("@"));

	let formIsValid = false;
	if (enteredNameIsValid && enteredEmailIsValid) {
		formIsValid = true;
	}

	const formSubmitHandler = (event) => {
		event.preventDefault(); //doing this only on submit handlers for form onSubmit

		if (!enteredNameIsValid || !enteredEmailIsValid) {
			return;
		}

		// you send out data herE.
		console.log(enteredName);
		console.log(enteredEmail);

		resetNameInput();
		resetEmailInput();
	};

	const nameInputClasses = nameInputHasError
		? "form-control invalid"
		: "form-control";
	const emailInputClasses = emailInputHasError
		? "form-control invalid"
		: "form-control";

	return (
		<form onSubmit={formSubmitHandler}>
			<div className={nameInputClasses}>
				<label htmlFor="name">Your Name</label>
				<input
					type="text"
					id="name"
					onChange={nameChangedHandler}
					onBlur={nameBlurHandler}
					value={enteredName}
				/>
				{nameInputHasError && (
					<p className="error-text">Name field must not be empty!</p>
				)}
			</div>
			<div className={emailInputClasses}>
				<label htmlFor="email">Your E-Mail</label>
				<input
					type="text"
					id="email"
					onChange={emailChangedHandler}
					onBlur={emailBlurHandler}
					value={enteredEmail}
				/>
				{emailInputHasError && (
					<p className="error-text">
						Entered email is not a valid email!
					</p>
				)}
			</div>
			<div className="form-actions">
				<button disabled={!formIsValid}>Submit</button>
			</div>
		</form>
	);
};

export default SimpleInput;
