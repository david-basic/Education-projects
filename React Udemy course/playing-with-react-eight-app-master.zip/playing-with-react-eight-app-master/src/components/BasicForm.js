import useInput from "../hooks/use-input-reducer";

const BasicForm = (props) => {
	const {
		value: fnameValue,
		isValid: fnameIsValid,
		hasError: fnameHasError,
		inputChangeHandler: fnameChangeHandler,
		inputBlurHandler: fnameBlurHandler,
		resetInput: resetFName,
	} = useInput((value) => value.trim() !== "");
	const {
		value: lnameValue,
		isValid: lnameIsValid,
		hasError: lnameHasError,
		inputChangeHandler: lnameChangeHandler,
		inputBlurHandler: lnameBlurHandler,
		resetInput: resetLName,
	} = useInput((value) => value.trim() !== "");
	const {
		value: emailValue,
		isValid: emailIsValid,
		hasError: emailHasError,
		inputChangeHandler: emailChangeHandler,
		inputBlurHandler: emailBlurHandler,
		resetInput: resetEmail,
	} = useInput((value) => value.trim() !== "" && value.includes("@"));

	let formIsValid = false;
	if (fnameIsValid && lnameIsValid && emailIsValid) {
		formIsValid = true;
	}

	const submitFormHandler = (e) => {
		e.preventDefault();

		if (!fnameIsValid || !emailIsValid || !lnameIsValid) {
			return;
		}

		// you send out data herE.
		console.log(fnameValue);
		console.log(lnameValue);
		console.log(emailValue);

		resetFName();
		resetLName();
		resetEmail();
	};

	const fnameInputClasses = fnameHasError
		? "form-control invalid"
		: "form-control";
	const lnameInputClasses = lnameHasError
		? "form-control invalid"
		: "form-control";
	const emailInputClasses = emailHasError
		? "form-control invalid"
		: "form-control";

	return (
		<form onSubmit={submitFormHandler}>
			<div className="control-group">
				<div className={fnameInputClasses}>
					<label htmlFor="fname">First Name</label>
					<input
						type="text"
						id="fname"
						value={fnameValue}
						onChange={fnameChangeHandler}
						onBlur={fnameBlurHandler}
					/>
					{fnameHasError && (
						<p className="error-text">
							First name field must not be empty!
						</p>
					)}
				</div>
				<div className={lnameInputClasses}>
					<label htmlFor="lname">Last Name</label>
					<input
						type="text"
						id="lname"
						value={lnameValue}
						onChange={lnameChangeHandler}
						onBlur={lnameBlurHandler}
					/>
					{lnameHasError && (
						<p className="error-text">
							Last name field must not be empty!
						</p>
					)}
				</div>
			</div>
			<div className={emailInputClasses}>
				<label htmlFor="email">E-Mail Address</label>
				<input
					type="text"
					id="email"
					value={emailValue}
					onChange={emailChangeHandler}
					onBlur={emailBlurHandler}
				/>
				{emailHasError && (
					<p className="error-text">
						Entered email is not a valid email!
					</p>
				)}
			</div>
			<div className="form-actions">
				<button disabled={!formIsValid}>Submit</button>
			</div>
		</form>
	);
};

export default BasicForm;
