import { useReducer } from "react";

const initalInputState = {
	value: "",
	isTouched: false,
};

const inputStateReducer = (prevState, action) => {
	if (action.type === "INPUT") {
		return { value: action.value, isTouched: prevState.isTouched };
	}
	if (action.type === "BLUR") {
		return { isTouched: true, value: prevState.value };
	}
	if (action.type === "RESET") {
		return { isTouched: false, value: "" };
	}

	return initalInputState;
};

const useInput = (validateValueFn) => {
	const [inputState, dispatchAction] = useReducer(
		inputStateReducer,
		initalInputState
	);

	const enteredValueIsValid = validateValueFn(inputState.value);
	const hasError = !enteredValueIsValid && inputState.isTouched;

	const inputChangeHandler = (e) => {
		dispatchAction({ type: "INPUT", value: e.target.value });
	};
	const inputBlurHandler = () => {
		dispatchAction({ type: "BLUR" });
	};
	const resetInput = () => {
		dispatchAction({ type: "RESET" });
	};

	return {
		value: inputState.value,
		isValid: enteredValueIsValid,
		hasError,
		inputChangeHandler,
		inputBlurHandler,
		resetInput,
	};
};

export default useInput;
