import { useState } from "react";

const useInput = (validateValueFn) => {
	const [value, setValue] = useState("");
	const [inputIsTouched, setInputIsTouched] = useState(false);

	const enteredValueIsValid = validateValueFn(value);
	const hasError = !enteredValueIsValid && inputIsTouched;

	const inputChangeHandler = (event) => {
		setValue(event.target.value);
	};
	const inputBlurHandler = () => {
		setInputIsTouched(true);
	};
	const resetInput = () => {
		setValue("");
		setInputIsTouched(false);
	};

	return {
		value,
		isValid: enteredValueIsValid,
		hasError,
		inputChangeHandler,
		inputBlurHandler,
		resetInput,
	};
};

export default useInput;
