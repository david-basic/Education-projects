import * as reactRouterDom from "react-router-dom";

import MainNavigation from "../components/MainNavigation";
import { useEffect } from "react";
import { getTokenDuration } from "../util/auth";

function RootLayout() {
	// const navigation = useNavigation();
	const token = reactRouterDom.useLoaderData();
	const submit = reactRouterDom.useSubmit();
	useEffect(() => {
		if (!token) {
			return;
		}

		if (token === "EXPIRED") {
			submit(null, { action: "/logout", method: "post" });
			return;
		}

		const tokenDuration = getTokenDuration();
		console.log(tokenDuration);

		setTimeout(() => {
			submit(null, { action: "/logout", method: "post" });
		}, tokenDuration);
	}, [submit, token]);

	return (
		<>
			<MainNavigation />
			<main>
				{/* {navigation.state === 'loading' && <p>Loading...</p>} */}
				<reactRouterDom.Outlet />
			</main>
		</>
	);
}

export default RootLayout;
