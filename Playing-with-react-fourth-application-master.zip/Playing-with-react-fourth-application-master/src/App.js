import React, { useContext } from "react";

import Login from "./components/Login/Login";
import Home from "./components/Home/Home";
import MainHeader from "./components/MainHeader/MainHeader";
import { AuthContext } from "./context/auth-context";

function App() {
	// const [isLoggedIn, setIsLoggedIn] = useState(false);

	// useEffect(() => {
	// 	const storedUserLoggedInInfo = localStorage.getItem("isLoggedIn");
	// 	if (storedUserLoggedInInfo === "LOGGED_IN") {
	// 		setIsLoggedIn(true);
	// 	}
	// }, []);

	// const loginHandler = (email, password) => {
	// 	// We should of course check email and password
	// 	// But it's just a dummy/ demo anyways

	// 	localStorage.setItem("isLoggedIn", "LOGGED_IN"); //using browser localstorage to store a key value pair, could have used "1" for logged in and "0" for logged out too
	// 	setIsLoggedIn(true);
	// };

	// const logoutHandler = () => {
	// 	localStorage.removeItem("isLoggedIn");
	// 	setIsLoggedIn(false);
	// };

	const ctx = useContext(AuthContext);

	return (
		<React.Fragment>
			<MainHeader />
			<main>
				{!ctx.isLoggedIn && <Login />}
				{ctx.isLoggedIn && <Home />}
			</main>
		</React.Fragment>
	);
}

export default App;
