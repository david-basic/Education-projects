import React, { Fragment } from "react";

import styleClasses from "./Modal.module.css";
import { createPortal } from "react-dom";

const BackDrop = (props) => {
	return <div className={styleClasses.backdrop} onClick={props.onClose}></div>;
};

const ModalOverlay = (props) => {
	return (
		<div className={styleClasses.modal}>
			<div className={styleClasses.content}>{props.children}</div>
		</div>
	);
};

const portalToElement = document.getElementById("overlays");

const Modal = (props) => {
	return (
		<Fragment>
			{createPortal(<BackDrop onClose={props.onClose} />, portalToElement)}
			{createPortal(
				<ModalOverlay>{props.children}</ModalOverlay>,
				portalToElement
			)}
		</Fragment>
	);
};

export default Modal;
