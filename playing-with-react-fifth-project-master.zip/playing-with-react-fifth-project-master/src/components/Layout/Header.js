import React, { Fragment } from "react";

import mealsImage from '../../assets/meals.jpg'
import styleClasses from './Header.module.css'
import HeaderCartButton from './HeaderCartButton'

const Header = (props) => {
	return (
		<Fragment>
			<header className={styleClasses.header}>
                <h1>ReactMeals</h1>
                <HeaderCartButton onClick={props.onShowCart}/>
            </header>
            <div className={styleClasses["main-image"]}>
                <img src={mealsImage} alt="Table with food."/>
            </div>
		</Fragment>
	);
};

export default Header;
